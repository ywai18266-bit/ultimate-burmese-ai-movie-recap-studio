-- Run in Supabase > SQL Editor. Run STATEMENT 1 alone first, then the rest.

-- STATEMENT 1
alter type job_status add value if not exists 'analysis_ready';

-- STATEMENT 2 (run after 1)
alter table public.jobs
  add column if not exists source_duration numeric,
  add column if not exists transcript_path text,
  add column if not exists scenes_path text;

create or replace function public.claim_next_job(p_worker text)
returns setof public.jobs
language plpgsql security definer set search_path = public as $$
declare j public.jobs;
begin
  select * into j from public.jobs where status = 'queued'
    order by created_at for update skip locked limit 1;
  if not found then return; end if;
  update public.jobs
    set status = 'extracting_audio', progress = 8, locked_by = p_worker, locked_at = now(), error = null
    where id = j.id returning * into j;
  return next j;
end $$;

revoke all on function public.claim_next_job(text) from public, anon, authenticated;
grant execute on function public.claim_next_job(text) to service_role;
