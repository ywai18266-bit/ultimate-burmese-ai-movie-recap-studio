-- Run in Supabase > SQL Editor (after schema.sql and stage2.sql).
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  voice_gender text not null default 'female' check (voice_gender in ('male','female')),
  voice_speed numeric not null default 1.0 check (voice_speed between 0.8 and 1.3),
  updated_at timestamptz not null default now()
);
alter table public.user_settings enable row level security;
create policy "own settings read"   on public.user_settings for select using (auth.uid() = user_id);
create policy "own settings insert" on public.user_settings for insert with check (auth.uid() = user_id);
create policy "own settings update" on public.user_settings for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
