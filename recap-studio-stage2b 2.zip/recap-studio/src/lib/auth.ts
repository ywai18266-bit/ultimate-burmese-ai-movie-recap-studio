import "server-only";
import { supabaseServer } from "@/lib/supabase/server";

export async function getUser() {
  const { data: { user } } = await supabaseServer().auth.getUser();
  return user;
}
