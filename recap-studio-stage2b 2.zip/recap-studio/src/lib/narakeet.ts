import "server-only";

// Official Narakeet REST API (docs: narakeet.com/docs/automating/). Key stays on the server.
const BASE = "https://api.narakeet.com";

export type NkVoice = { name: string; language: string; languageCode: string; styles?: string[] };

export class NarakeetError extends Error {
  constructor(message: string, public status?: number) { super(message); }
}

export const narakeetConfigured = () => !!process.env.NARAKEET_API_KEY;

function apiKey() {
  const k = process.env.NARAKEET_API_KEY;
  if (!k) throw new NarakeetError("Setup required: NARAKEET_API_KEY မသတ်မှတ်ရသေးပါ");
  return k;
}

async function explain(res: Response): Promise<string> {
  let detail = "";
  try {
    const t = await res.text();
    try { const j = JSON.parse(t); detail = j.message ?? j.error ?? t; } catch { detail = t; }
  } catch { /* ignore */ }
  if (res.status === 401 || res.status === 403) return `Narakeet API key မမှန်ပါ သို့မဟုတ် API access မရှိပါ (HTTP ${res.status}). ${detail}`.trim();
  if (res.status === 429) return "Narakeet ခေါ်ဆိုမှု များလွန်းသည် (rate/daily limit). ခဏစောင့်ပါ";
  return `Narakeet error HTTP ${res.status}: ${detail.slice(0, 300)}`;
}

// Docs recommend caching the voice list and calling it at most once per day.
let cache: { at: number; voices: NkVoice[] } | null = null;
const DAY = 24 * 3600 * 1000;

export async function listVoices(force = false): Promise<NkVoice[]> {
  if (!force && cache && Date.now() - cache.at < DAY) return cache.voices;
  const res = await fetch(`${BASE}/voices`, { headers: { "x-api-key": apiKey() }, cache: "no-store" });
  if (!res.ok) throw new NarakeetError(await explain(res), res.status);
  const data: unknown = await res.json();
  if (!Array.isArray(data)) throw new NarakeetError("Narakeet voice list ပုံစံ မမှန်ပါ");
  const voices = data
    .filter((v: any) => v && typeof v.name === "string")
    .map((v: any) => ({ name: v.name, language: String(v.language ?? ""), languageCode: String(v.languageCode ?? ""), styles: v.styles }));
  cache = { at: Date.now(), voices };
  return voices;
}

export const isBurmese = (v: NkVoice) => /^my([-_]|$)/i.test(v.languageCode) || /burmese|myanmar/i.test(v.language);

export function voiceSlots() {
  return {
    male: process.env.NARAKEET_MALE_VOICE ?? "zeya",
    female: process.env.NARAKEET_FEMALE_VOICE ?? "sanda",
  };
}

/** Live check against the official voice-list API. Never assumes a voice exists. */
export async function verifyVoices(force = false) {
  const voices = await listVoices(force);
  const slots = voiceSlots();
  const check = (requested: string) => {
    const v = voices.find((x) => x.name.toLowerCase() === requested.toLowerCase());
    return { requested, found: !!v, apiName: v?.name ?? null, language: v?.language ?? null, languageCode: v?.languageCode ?? null, isBurmese: v ? isBurmese(v) : false };
  };
  const male = check(slots.male);
  const female = check(slots.female);
  return {
    totalVoices: voices.length,
    burmeseVoices: voices.filter(isBurmese).map((v) => ({ name: v.name, language: v.language, languageCode: v.languageCode })),
    male, female,
    ok: male.found && male.isBurmese && female.found && female.isBurmese,
  };
}

/** Short-content (streaming) API: POST /text-to-speech/mp3, accept: application/octet-stream. Max 1 KB UTF-8. */
export async function synthesizeMp3(voiceName: string, text: string, speed: number) {
  const bytes = Buffer.byteLength(text, "utf8");
  if (bytes > 1000) throw new NarakeetError(`စာသား ရှည်လွန်းသည် (${bytes} bytes). Preview အတွက် အများဆုံး 1000 bytes (မြန်မာစာလုံး ~၃၀၀)`);
  const url = `${BASE}/text-to-speech/mp3?voice=${encodeURIComponent(voiceName)}&voice-speed=${speed}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "x-api-key": apiKey(), "Content-Type": "text/plain", accept: "application/octet-stream" },
    body: text,
    cache: "no-store",
  });
  if (!res.ok) throw new NarakeetError(await explain(res), res.status);
  if ((res.headers.get("content-type") ?? "").includes("application/json")) {
    throw new NarakeetError(`Narakeet: ${(await res.text()).slice(0, 300)}`);
  }
  const audio = Buffer.from(await res.arrayBuffer());
  if (audio.length < 100) throw new NarakeetError("Narakeet က အသံဖိုင် ဗလာ ပြန်ပို့သည်");
  return { audio, duration: Number(res.headers.get("x-duration-seconds")) || null };
}
