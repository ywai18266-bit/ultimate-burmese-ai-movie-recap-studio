import { NextResponse } from "next/server";
import { z } from "zod";
import { getUser } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";

const Body = z.object({ gender: z.enum(["male", "female"]), speed: z.number().min(0.8).max(1.3) });

export async function PUT(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "ဝင်ရောက်ရန် လိုအပ်သည်" }, { status: 401 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });

  const { error } = await supabaseServer().from("user_settings").upsert({
    user_id: user.id, voice_gender: parsed.data.gender, voice_speed: parsed.data.speed, updated_at: new Date().toISOString(),
  });
  if (error) return NextResponse.json({ error: `Database: ${error.message} (supabase/stage2b.sql ကို run ပြီးပါပြီလား?)` }, { status: 500 });
  return NextResponse.json({ ok: true });
}
