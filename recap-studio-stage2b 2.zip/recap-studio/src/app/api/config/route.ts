import { NextResponse } from "next/server";
import { configStatus } from "@/lib/env";
import { supabaseServer } from "@/lib/supabase/server";

export async function GET() {
  const { data: { user } } = await supabaseServer().auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ providers: configStatus() });
}
