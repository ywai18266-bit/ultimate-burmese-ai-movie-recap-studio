import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const sb = supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "ဝင်ရောက်ရန် လိုအပ်သည်" }, { status: 401 });

  const admin = supabaseAdmin();
  const { data: job } = await admin.from("jobs").select("id,user_id,status,source_path,source_size").eq("id", params.id).single();
  if (!job || job.user_id !== user.id) return NextResponse.json({ error: "Job မတွေ့ပါ" }, { status: 404 });
  if (job.status !== "uploading") return NextResponse.json({ error: "Job သည် upload အဆင့်တွင် မရှိတော့ပါ" }, { status: 409 });

  // Verify the file truly landed in storage (never fake success)
  const dir = `${user.id}/${job.id}`;
  const { data: files, error } = await admin.storage.from("sources").list(dir);
  const found = files?.find((f) => `${dir}/${f.name}` === job.source_path);
  if (error || !found) {
    await admin.from("jobs").update({ status: "failed", error: "ဖိုင်ကို Storage တွင် မတွေ့ပါ — ပြန်တင်ကြည့်ပါ" }).eq("id", job.id);
    return NextResponse.json({ error: "ဖိုင်ကို Storage တွင် မတွေ့ပါ" }, { status: 422 });
  }

  await admin.from("jobs").update({ status: "queued", progress: 5 }).eq("id", job.id);
  await admin.from("job_events").insert({ job_id: job.id, status: "queued", message: "Upload verified" });
  return NextResponse.json({ ok: true });
}
