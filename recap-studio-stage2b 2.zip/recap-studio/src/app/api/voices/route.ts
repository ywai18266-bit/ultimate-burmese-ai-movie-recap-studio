import { NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { narakeetConfigured, verifyVoices, NarakeetError } from "@/lib/narakeet";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "ဝင်ရောက်ရန် လိုအပ်သည်" }, { status: 401 });

  const { data: s } = await supabaseServer().from("user_settings").select("voice_gender,voice_speed").maybeSingle();
  const settings = { gender: s?.voice_gender ?? "female", speed: Number(s?.voice_speed ?? 1) };

  if (!narakeetConfigured()) {
    return NextResponse.json({ configured: false, settings, message: "Setup required: NARAKEET_API_KEY ကို server environment တွင် ထည့်ပါ" });
  }
  try {
    const force = new URL(req.url).searchParams.get("refresh") === "1";
    return NextResponse.json({ configured: true, settings, verification: await verifyVoices(force) });
  } catch (e) {
    const msg = e instanceof NarakeetError ? e.message : String(e);
    return NextResponse.json({ configured: true, settings, error: msg }, { status: 502 });
  }
}
