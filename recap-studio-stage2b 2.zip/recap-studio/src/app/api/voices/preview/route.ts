import { NextResponse } from "next/server";
import { z } from "zod";
import { getUser } from "@/lib/auth";
import { listVoices, voiceSlots, isBurmese, synthesizeMp3, narakeetConfigured, NarakeetError } from "@/lib/narakeet";

export const dynamic = "force-dynamic";

const Body = z.object({
  gender: z.enum(["male", "female"]),
  text: z.string().trim().min(1).max(400),
  speed: z.number().min(0.8).max(1.3).default(1),
});

// Simple per-user limiter (per server instance) to protect your Narakeet credits.
const hits = new Map<string, number[]>();
function limited(id: string) {
  const now = Date.now();
  const arr = (hits.get(id) ?? []).filter((t) => now - t < 60_000);
  if (arr.length >= 8) { hits.set(id, arr); return true; }
  arr.push(now); hits.set(id, arr); return false;
}

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "ဝင်ရောက်ရန် လိုအပ်သည်" }, { status: 401 });
  if (!narakeetConfigured()) return NextResponse.json({ error: "Setup required: NARAKEET_API_KEY မသတ်မှတ်ရသေးပါ" }, { status: 503 });
  if (limited(user.id)) return NextResponse.json({ error: "Preview တစ်မိနစ်လျှင် ၈ ကြိမ်သာ ခွင့်ပြုသည်" }, { status: 429 });

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const { gender, text, speed } = parsed.data;

  try {
    const wanted = voiceSlots()[gender];
    const v = (await listVoices()).find((x) => x.name.toLowerCase() === wanted.toLowerCase());
    if (!v) return NextResponse.json({ error: `Narakeet voice list တွင် "${wanted}" မတွေ့ပါ` }, { status: 404 });
    if (!isBurmese(v)) return NextResponse.json({ error: `"${v.name}" သည် Burmese voice မဟုတ်ပါ (${v.languageCode})` }, { status: 422 });

    const { audio, duration } = await synthesizeMp3(v.name, text, speed);
    return new Response(new Uint8Array(audio), {
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store", ...(duration ? { "x-duration-seconds": String(duration) } : {}) },
    });
  } catch (e) {
    const status = e instanceof NarakeetError && e.status ? (e.status === 401 || e.status === 403 ? 502 : e.status) : 502;
    return NextResponse.json({ error: e instanceof Error ? e.message : String(e) }, { status });
  }
}
