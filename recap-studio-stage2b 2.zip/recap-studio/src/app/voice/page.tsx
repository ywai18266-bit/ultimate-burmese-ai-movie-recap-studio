"use client";
import { useEffect, useRef, useState } from "react";
import Shell from "@/components/Shell";

const SAMPLE = "မင်္ဂလာပါ။ ဒီနေ့ ရုပ်ရှင်ဇာတ်လမ်းတစ်ပုဒ်ကို ပြန်ပြောပြပေးပါမယ်။";

type Check = { requested: string; found: boolean; apiName: string | null; language: string | null; languageCode: string | null; isBurmese: boolean };
type Info = {
  configured: boolean; message?: string; error?: string;
  settings: { gender: "male" | "female"; speed: number };
  verification?: { totalVoices: number; burmeseVoices: { name: string; languageCode: string }[]; male: Check; female: Check; ok: boolean };
};

export default function VoicePage() {
  const [info, setInfo] = useState<Info | null>(null);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [gender, setGender] = useState<"male" | "female">("female");
  const [speed, setSpeed] = useState(1);
  const [text, setText] = useState(SAMPLE);
  const [busy, setBusy] = useState<"" | "preview" | "save" | "check">("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  async function load(refresh = false) {
    setBusy("check"); setLoadErr(null);
    try {
      const r = await fetch(`/api/voices${refresh ? "?refresh=1" : ""}`);
      const j = await r.json();
      setInfo(j);
      if (j.settings) { setGender(j.settings.gender); setSpeed(j.settings.speed); }
      if (!r.ok && j.error) setLoadErr(j.error);
    } catch (e) { setLoadErr(String(e)); }
    setBusy("");
  }
  useEffect(() => { load(); }, []);

  async function preview() {
    setBusy("preview"); setMsg(null);
    try {
      const r = await fetch("/api/voices/preview", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gender, text, speed }),
      });
      if (!r.ok) throw new Error((await r.json()).error ?? `HTTP ${r.status}`);
      const url = URL.createObjectURL(await r.blob());
      if (src) URL.revokeObjectURL(src);
      setSrc(url);
      setTimeout(() => audioRef.current?.play().catch(() => setMsg({ ok: true, text: "▶ ခလုတ်ကို နှိပ်၍ နားထောင်ပါ" })), 50);
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : String(e) }); }
    setBusy("");
  }

  async function save() {
    setBusy("save"); setMsg(null);
    const r = await fetch("/api/settings/voice", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ gender, speed }) });
    const j = await r.json();
    setMsg(r.ok ? { ok: true, text: "သိမ်းပြီးပါပြီ" } : { ok: false, text: j.error });
    setBusy("");
  }

  const v = info?.verification;
  const row = (label: string, c?: Check) => c && (
    <li className={c.found && c.isBurmese ? "text-emerald-300" : "text-red-300"}>
      {c.found && c.isBurmese ? "✅" : "❌"} {label}: <b>{c.requested}</b>
      {c.found ? ` — ${c.language} (${c.languageCode})${c.isBurmese ? "" : " — Burmese မဟုတ်ပါ"}` : " — Narakeet voice list တွင် မတွေ့ပါ"}
    </li>
  );

  return (
    <Shell title="AI အသံ">
      <div className="space-y-4">
        <div className="card">
          <div className="mb-2 flex items-center justify-between">
            <b>Narakeet အခြေအနေ</b>
            <button className="rounded-lg border border-zinc-700 px-3 py-1 text-sm" onClick={() => load(true)} disabled={busy !== ""}>
              {busy === "check" ? "စစ်နေသည်…" : "ပြန်စစ်ရန်"}
            </button>
          </div>
          {info && !info.configured && <p className="text-amber-300">⚠ {info.message}</p>}
          {loadErr && <p className="text-red-300">{loadErr}</p>}
          {v && (
            <>
              <ul className="space-y-1 text-sm">{row("ယောက်ျားအသံ", v.male)}{row("မိန်းမအသံ", v.female)}</ul>
              <p className="mt-2 text-xs text-zinc-500">Voice list စုစုပေါင်း {v.totalVoices} ခု၊ Burmese: {v.burmeseVoices.map((b) => b.name).join(", ") || "မတွေ့ပါ"}</p>
            </>
          )}
        </div>

        <div className="card space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {(["male", "female"] as const).map((g) => {
              const c = v?.[g];
              return (
                <button key={g} onClick={() => setGender(g)}
                  className={`rounded-xl border p-4 text-left ${gender === g ? "border-gold-500 bg-zinc-800" : "border-zinc-700"}`}>
                  <div className="text-lg font-bold">{g === "male" ? "👨 ယောက်ျားအသံ" : "👩 မိန်းမအသံ"}</div>
                  <div className="text-sm text-zinc-400">{c?.apiName ?? c?.requested ?? (g === "male" ? "Zeya" : "Sanda")}</div>
                </button>
              );
            })}
          </div>
          <label className="block text-sm">အမြန်နှုန်း: {speed.toFixed(2)}×
            <input type="range" min={0.8} max={1.3} step={0.05} value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))} className="mt-1 w-full" />
          </label>
          <textarea className="field h-28" value={text} onChange={(e) => setText(e.target.value)} maxLength={400} />
          <div className="flex gap-3">
            <button className="btn flex-1" onClick={preview} disabled={busy !== "" || !info?.configured}>{busy === "preview" ? "ဖန်တီးနေသည်…" : "▶ နားထောင်ကြည့်ရန်"}</button>
            <button className="btn flex-1 !bg-zinc-700 !text-zinc-100" onClick={save} disabled={busy !== ""}>သိမ်းရန်</button>
          </div>
          {src && <audio ref={audioRef} src={src} controls className="w-full" />}
          {msg && <p className={msg.ok ? "text-emerald-300" : "text-red-300"}>{msg.text}</p>}
        </div>
      </div>
    </Shell>
  );
}
