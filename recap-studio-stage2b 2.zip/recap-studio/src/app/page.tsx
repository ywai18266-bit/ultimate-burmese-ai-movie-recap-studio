import Link from "next/link";
import Shell from "@/components/Shell";
import { supabaseServer } from "@/lib/supabase/server";
import { configStatus } from "@/lib/env";
import { STATUS_LABELS } from "@/lib/jobs";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const sb = supabaseServer();
  const { data: jobs, error } = await sb
    .from("jobs")
    .select("id,title,status,progress,error,created_at")
    .order("created_at", { ascending: false })
    .limit(20);
  const providers = configStatus();
  const missing = providers.filter((p) => !p.configured);

  return (
    <Shell title="ဒက်ရှ်ဘုတ်">
      {missing.length > 0 && (
        <div className="card mb-4 border-amber-700/60">
          <div className="mb-2 font-bold text-amber-300">⚠ ဆက်တင် လိုအပ်နေသည် (Setup required)</div>
          <ul className="space-y-1 text-sm text-zinc-300">
            {missing.map((p) => (
              <li key={p.key}><b>{p.label}</b> — မသတ်မှတ်ရသေးပါ။ လိုအပ်သော env: <code className="text-gold-400">{p.hint}</code></li>
            ))}
          </ul>
        </div>
      )}
      <Link href="/upload" className="btn mb-4 w-full md:w-auto">＋ ဗီဒီယိုအသစ် တင်ရန်</Link>
      {error && <p className="card text-red-300">Database error: {error.message}. supabase/schema.sql ကို run ပြီးပါပြီလား?</p>}
      <div className="space-y-3">
        {(jobs ?? []).map((j) => (
          <div key={j.id} className="card">
            <div className="flex items-center justify-between gap-2">
              <div className="truncate font-bold">{j.title}</div>
              <span className={`rounded-full px-3 py-1 text-xs ${j.status === "failed" ? "bg-red-900 text-red-200" : j.status === "completed" ? "bg-emerald-900 text-emerald-200" : "bg-zinc-800 text-gold-400"}`}>
                {STATUS_LABELS[j.status] ?? j.status}
              </span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded bg-zinc-800">
              <div className="h-full bg-gold-500" style={{ width: `${j.progress}%` }} />
            </div>
            <div className="mt-1 text-xs text-zinc-500">{j.progress}%</div>
            {j.error && <p className="mt-2 text-sm text-red-300">အမှား: {j.error}</p>}
          </div>
        ))}
        {jobs?.length === 0 && <p className="text-zinc-500">လုပ်ငန်း မရှိသေးပါ။</p>}
      </div>
    </Shell>
  );
}
