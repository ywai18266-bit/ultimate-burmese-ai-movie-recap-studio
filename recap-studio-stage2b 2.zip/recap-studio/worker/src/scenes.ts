import { readFile } from "node:fs/promises";
import { frameAt } from "./ffmpeg.js";

export type Scene = { index: number; start: number; end: number; caption?: string };

export function buildScenes(cuts: number[], duration: number, minLen = 4, maxScenes = 60) {
  let method: "scene-detect" | "interval" = "scene-detect";
  const pts = [0, ...cuts.filter((t) => t > 0 && t < duration).sort((a, b) => a - b)];
  let starts: number[] = [];
  for (const t of pts) if (!starts.length || t - starts[starts.length - 1] >= minLen) starts.push(t);
  if (starts.length < 8 && duration > 600) {
    method = "interval"; // too few detected cuts: fall back to an even time grid (labelled as such)
    starts = Array.from({ length: 40 }, (_, i) => (duration / 40) * i);
  } else if (starts.length > maxScenes) {
    const step = starts.length / maxScenes;
    starts = Array.from({ length: maxScenes }, (_, i) => starts[Math.floor(i * step)]);
  }
  const scenes: Scene[] = starts.map((s, i) => ({ index: i, start: +s.toFixed(2), end: +(starts[i + 1] ?? duration).toFixed(2) }));
  return { method, scenes };
}

/** Describes one keyframe per scene using Claude vision. Real API call; fails loudly if unconfigured. */
export async function captionScenes(src: string, dir: string, scenes: Scene[], onProgress: (done: number, total: number) => Promise<void>) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("Setup required: ANTHROPIC_API_KEY မသတ်မှတ်ရသေးပါ (worker host တွင် ထည့်ပါ)");
  const model = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-6";
  const BATCH = 6;
  for (let i = 0; i < scenes.length; i += BATCH) {
    const batch = scenes.slice(i, i + BATCH);
    const content: any[] = [];
    for (const [k, sc] of batch.entries()) {
      const out = `${dir}/frame_${sc.index}.jpg`;
      await frameAt(src, (sc.start + sc.end) / 2, out);
      content.push({ type: "text", text: `Frame ${k + 1}:` });
      content.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: (await readFile(out)).toString("base64") } });
    }
    content.push({ type: "text", text: `These are ${batch.length} frames from a movie, in order. For each frame write one factual sentence (max 25 words) about the visible setting, action and characters by appearance only. Do not guess actor or character names. Reply with ONLY a JSON array of ${batch.length} strings.` });
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model, max_tokens: 1200, messages: [{ role: "user", content }] }),
    });
    if (!res.ok) throw new Error(`Claude API error ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const j: any = await res.json();
    const text: string = j.content?.[0]?.text ?? "";
    const arr = JSON.parse(text.slice(text.indexOf("["), text.lastIndexOf("]") + 1));
    if (!Array.isArray(arr) || arr.length !== batch.length) throw new Error("Claude caption response had the wrong shape");
    batch.forEach((sc, k) => (sc.caption = String(arr[k])));
    await onProgress(Math.min(i + BATCH, scenes.length), scenes.length);
  }
}
