import { createWriteStream } from "node:fs";
import { mkdir, rm } from "node:fs/promises";
import { Readable } from "node:stream";
import { pipeline as streamPipeline } from "node:stream/promises";
import path from "node:path";
import { sb, setStatus, failJob, uploadJson, type Job } from "./db.js";
import { extractAudio, splitAudio, probeDuration, hasAudio, detectCuts } from "./ffmpeg.js";
import { transcribeChunk, type Seg } from "./whisper.js";
import { buildScenes, captionScenes } from "./scenes.js";
import { readdir } from "node:fs/promises";

const WORK_DIR = process.env.WORK_DIR ?? "/tmp/recap";
const MAX_MIN = Number(process.env.MAX_DURATION_MIN ?? 240);
const CHUNK_SECONDS = 1200;

async function downloadSource(job: Job, dest: string) {
  const { data, error } = await sb.storage.from("sources").createSignedUrl(job.source_path, 3600);
  if (error || !data) throw new Error(`Source signed URL failed: ${error?.message}`);
  const res = await fetch(data.signedUrl);
  if (!res.ok || !res.body) throw new Error(`Source download failed: HTTP ${res.status}`);
  await streamPipeline(Readable.fromWeb(res.body as any), createWriteStream(dest));
}

export async function processJob(job: Job) {
  const dir = path.join(WORK_DIR, job.id);
  try {
    await mkdir(path.join(dir, "chunks"), { recursive: true });
    await mkdir(path.join(dir, "frames"), { recursive: true });
    const src = path.join(dir, "source");

    await setStatus(job.id, "extracting_audio", 8, "Downloading source from storage");
    await downloadSource(job, src);

    const duration = await probeDuration(src);
    if (duration > MAX_MIN * 60) throw new Error(`ဗီဒီယိုကြာချိန် ${(duration / 60).toFixed(0)} မိနစ် — ကန့်သတ်ချက် ${MAX_MIN} မိနစ်ထက် ကျော်နေသည်`);
    if (!(await hasAudio(src))) throw new Error("ဤဗီဒီယိုတွင် အသံ track မရှိပါ");
    await sb.from("jobs").update({ source_duration: duration }).eq("id", job.id);

    // 1) Audio extraction (FFmpeg)
    await setStatus(job.id, "extracting_audio", 12, "Extracting audio with FFmpeg");
    const audio = path.join(dir, "audio.mp3");
    await extractAudio(src, audio);
    await splitAudio(audio, path.join(dir, "chunks"), CHUNK_SECONDS);
    const chunks = (await readdir(path.join(dir, "chunks"))).filter((f) => f.endsWith(".mp3")).sort();
    if (chunks.length === 0) throw new Error("FFmpeg audio chunk မထွက်ပါ");

    // 2) Transcription (OpenAI Whisper), chunk by chunk with time offsets
    const segments: Seg[] = [];
    let language = "unknown";
    for (const [i, name] of chunks.entries()) {
      const offset = i * CHUNK_SECONDS;
      const r = await transcribeChunk(path.join(dir, "chunks", name));
      if (i === 0 || language === "unknown") language = r.language;
      for (const s of r.segments) segments.push({ start: s.start + offset, end: s.end + offset, text: s.text });
      await setStatus(job.id, "extracting_audio", 12 + Math.round(((i + 1) / chunks.length) * 23), `Transcribed chunk ${i + 1}/${chunks.length}`);
    }
    const transcriptPath = await uploadJson(job.user_id, job.id, "transcript.json", { language, duration, segments });

    // 3) Scene analysis: FFmpeg cut detection + Claude vision captions
    await setStatus(job.id, "analyzing_scenes", 38, "Detecting scene changes");
    const cuts = await detectCuts(src);
    const { method, scenes } = buildScenes(cuts, duration);
    await captionScenes(src, path.join(dir, "frames"), scenes, (done, total) =>
      setStatus(job.id, "analyzing_scenes", 38 + Math.round((done / total) * 7), `Captioned ${done}/${total} scenes`));
    const scenesPath = await uploadJson(job.user_id, job.id, "scenes.json", { method, duration, scenes });

    // Honest end state for Stage 2: analysis is real; the script step ships in Stage 3.
    await setStatus(job.id, "analysis_ready", 45,
      `Done: ${segments.length} transcript segments (${language}), ${scenes.length} scenes (${method})`,
      { transcript_path: transcriptPath, scenes_path: scenesPath, locked_by: null });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[job ${job.id}]`, msg);
    await failJob(job.id, msg);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}
