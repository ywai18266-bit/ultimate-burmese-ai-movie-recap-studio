import { spawn } from "node:child_process";

export function run(cmd: string, args: string[]): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args);
    let stdout = "", stderr = "";
    p.stdout.on("data", (d) => { if (stdout.length < 8e6) stdout += d; });
    p.stderr.on("data", (d) => { if (stderr.length < 8e6) stderr += d; });
    p.on("error", (e) => reject(new Error(`${cmd} could not start: ${e.message}. FFmpeg ထည့်သွင်းထားပါသလား?`)));
    p.on("close", (code) => code === 0 ? resolve({ stdout, stderr }) : reject(new Error(`${cmd} exited ${code}: ${stderr.slice(-1500)}`)));
  });
}

export async function probeDuration(file: string): Promise<number> {
  const { stdout } = await run("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]);
  const d = parseFloat(stdout.trim());
  if (!Number.isFinite(d) || d <= 0) throw new Error("ဗီဒီယိုကြာချိန် ဖတ်မရပါ — ဖိုင်ပျက်စီးနေနိုင်သည်");
  return d;
}

export async function hasAudio(file: string): Promise<boolean> {
  const { stdout } = await run("ffprobe", ["-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", file]);
  return stdout.trim().length > 0;
}

// Mono 16 kHz MP3 @32 kbps: ~4 KB/s, so a 20-min chunk is ~4.8 MB (well under Whisper's 25 MB limit)
export const extractAudio = (src: string, out: string) =>
  run("ffmpeg", ["-y", "-i", src, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "32k", out]);

export const splitAudio = (src: string, dir: string, seconds: number) =>
  run("ffmpeg", ["-y", "-i", src, "-f", "segment", "-segment_time", String(seconds), "-c", "copy", `${dir}/chunk_%03d.mp3`]);

/** Scene-change timestamps. fps+scale first so a full movie is analysed quickly. */
export async function detectCuts(src: string, threshold = 0.3): Promise<number[]> {
  const { stderr } = await run("ffmpeg", [
    "-nostats", "-i", src, "-an", "-sn",
    "-vf", `fps=2,scale=320:-2,select='gt(scene,${threshold})',showinfo`, "-f", "null", "-",
  ]);
  return [...stderr.matchAll(/pts_time:([\d.]+)/g)].map((m) => parseFloat(m[1]));
}

export const frameAt = (src: string, t: number, out: string) =>
  run("ffmpeg", ["-y", "-ss", t.toFixed(2), "-i", src, "-frames:v", "1", "-vf", "scale=640:-2", "-q:v", "4", out]);
