import { readFile } from "node:fs/promises";

export type Seg = { start: number; end: number; text: string };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Real call to OpenAI POST /v1/audio/transcriptions (model whisper-1). Language is auto-detected. */
export async function transcribeChunk(file: string): Promise<{ language: string; segments: Seg[] }> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("Setup required: OPENAI_API_KEY မသတ်မှတ်ရသေးပါ (worker host တွင် ထည့်ပါ)");
  const bytes = await readFile(file);
  for (let attempt = 1; attempt <= 4; attempt++) {
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: "audio/mpeg" }), "audio.mp3");
    form.append("model", "whisper-1");
    form.append("response_format", "verbose_json");
    form.append("timestamp_granularities[]", "segment");
    const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST", headers: { Authorization: `Bearer ${key}` }, body: form,
    });
    if (res.ok) {
      const j: any = await res.json();
      return {
        language: j.language ?? "unknown",
        segments: (j.segments ?? []).map((s: any) => ({ start: s.start, end: s.end, text: String(s.text).trim() })),
      };
    }
    const body = await res.text();
    if ((res.status === 429 || res.status >= 500) && attempt < 4) { await sleep(2000 * 2 ** attempt); continue; }
    throw new Error(`OpenAI Whisper error ${res.status}: ${body.slice(0, 300)}`);
  }
  throw new Error("Whisper retries exhausted");
}
