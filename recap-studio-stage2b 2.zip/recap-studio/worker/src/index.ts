import { sb, type Job } from "./db.js";
import { processJob } from "./pipeline.js";
import { run } from "./ffmpeg.js";

const WORKER_ID = process.env.WORKER_ID ?? `worker-${process.pid}`;
const POLL_MS = Number(process.env.POLL_MS ?? 5000);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function main() {
  for (const k of ["NEXT_PUBLIC_SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"]) {
    if (!process.env[k]) { console.error(`Missing env ${k}`); process.exit(1); }
  }
  await run("ffmpeg", ["-version"]); // fails loudly if FFmpeg is not installed
  console.log(`[${WORKER_ID}] started`);

  // Jobs this worker was running when it last died can never finish: fail them honestly.
  await sb.from("jobs").update({ status: "failed", error: "Worker ရပ်သွားခဲ့သည် — ပြန်တင်ကြည့်ပါ", locked_by: null })
    .eq("locked_by", WORKER_ID).in("status", ["extracting_audio", "analyzing_scenes"]);

  for (;;) {
    const { data, error } = await sb.rpc("claim_next_job", { p_worker: WORKER_ID });
    if (error) { console.error("claim error:", error.message); await sleep(POLL_MS * 2); continue; }
    const job = (data as Job[] | null)?.[0];
    if (!job) { await sleep(POLL_MS); continue; }
    console.log(`[${WORKER_ID}] processing ${job.id}`);
    await processJob(job);
  }
}
main().catch((e) => { console.error(e); process.exit(1); });
