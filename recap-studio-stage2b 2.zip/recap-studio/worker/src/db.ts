import { createClient } from "@supabase/supabase-js";

export const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false },
});

export type Job = { id: string; user_id: string; title: string; source_path: string };

export async function setStatus(id: string, status: string, progress: number, message?: string, extra: Record<string, unknown> = {}) {
  const { error } = await sb.from("jobs").update({ status, progress, ...extra }).eq("id", id);
  if (error) throw new Error(`DB update failed: ${error.message}`);
  await sb.from("job_events").insert({ job_id: id, status, message: message ?? null });
}

export async function failJob(id: string, message: string) {
  await sb.from("jobs").update({ status: "failed", error: message.slice(0, 1000), locked_by: null }).eq("id", id);
  await sb.from("job_events").insert({ job_id: id, status: "failed", message: message.slice(0, 1000) });
}

export async function uploadJson(userId: string, jobId: string, name: string, data: unknown) {
  const p = `${userId}/${jobId}/${name}`;
  const { error } = await sb.storage.from("outputs").upload(p, Buffer.from(JSON.stringify(data)), {
    contentType: "application/json", upsert: true,
  });
  if (error) throw new Error(`Storage upload (${name}) failed: ${error.message}`);
  return p;
}
